

// Node 链接Mongodb数据库 
// Mongoose 

const mongoose = require('mongoose')

const hostname = "localhost"
const port = 27017
const dbname = "fx2301"
const user = '?'
const pwd = "?"

const CONN_DB_URL = `mongodb://${hostname}:${port}/${dbname}`;
mongoose.set('strictQuery', false)
mongoose.connect(CONN_DB_URL,(err)=>{
    if(err){
        console.log('数据库链接失败')
        console.log(err)
    }else{  
        console.log('数据库链接成功 ' + new Date())
    }
})
